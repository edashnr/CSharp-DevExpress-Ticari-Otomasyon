--Count, Avg, Sum

--Count sayar
--select COUNT(*) from TBL_FIRMALAR where IL='Eski�ehir' or IL='Adana'

--avg ortalama al�r
--select avg(SATISFIYAT) from TBL_URUNLER

--sum toplama i�lemi yapar
--select sum(sat�sf�yat) from TBL_URUNLER
--select (sum(sat�sf�yat*adet))-(sum(al�sf�yat*adet)) from TBL_URUNLER