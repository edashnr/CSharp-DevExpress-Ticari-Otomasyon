﻿
namespace Ticari_Otomasyon
{
    partial class FrmKasa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmKasa));
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.SideBySideBarSeriesView sideBySideBarSeriesView1 = new DevExpress.XtraCharts.SideBySideBarSeriesView();
            DevExpress.XtraCharts.XYDiagram xyDiagram2 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.gridControl2 = new DevExpress.XtraGrid.GridControl();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.groupControl13 = new DevExpress.XtraEditors.GroupControl();
            this.chartControl2 = new DevExpress.XtraCharts.ChartControl();
            this.groupControl12 = new DevExpress.XtraEditors.GroupControl();
            this.chartControl1 = new DevExpress.XtraCharts.ChartControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.gridControl3 = new DevExpress.XtraGrid.GridControl();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.groupControl9 = new DevExpress.XtraEditors.GroupControl();
            this.LblAktifKullanıcı = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupControl8 = new DevExpress.XtraEditors.GroupControl();
            this.LblStokSayısı = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupControl6 = new DevExpress.XtraEditors.GroupControl();
            this.LblMüsteriSehirSayısı = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.LblFirmaSehirSayısı = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupControl7 = new DevExpress.XtraEditors.GroupControl();
            this.LblPersonelSayısı = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupControl5 = new DevExpress.XtraEditors.GroupControl();
            this.LblFirmaSayısı = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.LblMüsteriSayısı = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.LblPersonelMaasları = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.LblÖdemeler = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.LblKasaToplam = new System.Windows.Forms.Label();
            this.LblToplamTutar = new System.Windows.Forms.Label();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl13)).BeginInit();
            this.groupControl13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(sideBySideBarSeriesView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl12)).BeginInit();
            this.groupControl12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl9)).BeginInit();
            this.groupControl9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl8)).BeginInit();
            this.groupControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl6)).BeginInit();
            this.groupControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl7)).BeginInit();
            this.groupControl7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).BeginInit();
            this.groupControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.gridControl2);
            this.xtraTabPage2.Controls.Add(this.groupControl13);
            this.xtraTabPage2.Controls.Add(this.groupControl12);
            this.xtraTabPage2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage2.ImageOptions.Image")));
            this.xtraTabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(1538, 723);
            this.xtraTabPage2.Text = "Kasa Çıkış Hareketleri";
            // 
            // gridControl2
            // 
            this.gridControl2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl2.Location = new System.Drawing.Point(412, 4);
            this.gridControl2.MainView = this.gridView2;
            this.gridControl2.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl2.Name = "gridControl2";
            this.gridControl2.Size = new System.Drawing.Size(1625, 715);
            this.gridControl2.TabIndex = 12;
            this.gridControl2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // gridView2
            // 
            this.gridView2.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gridView2.Appearance.Row.Options.UseBackColor = true;
            this.gridView2.DetailHeight = 431;
            this.gridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView2.GridControl = this.gridControl2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsEditForm.PopupEditFormWidth = 1067;
            // 
            // groupControl13
            // 
            this.groupControl13.Controls.Add(this.chartControl2);
            this.groupControl13.Location = new System.Drawing.Point(0, 363);
            this.groupControl13.Name = "groupControl13";
            this.groupControl13.Size = new System.Drawing.Size(405, 353);
            this.groupControl13.TabIndex = 11;
            this.groupControl13.Text = "groupControl13";
            // 
            // chartControl2
            // 
            this.chartControl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.chartControl2.BorderOptions.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.chartControl2.BorderOptions.Visibility = DevExpress.Utils.DefaultBoolean.True;
            xyDiagram1.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram1.AxisY.VisibleInPanesSerializable = "-1";
            this.chartControl2.Diagram = xyDiagram1;
            this.chartControl2.Legend.LegendID = -1;
            this.chartControl2.Location = new System.Drawing.Point(0, 27);
            this.chartControl2.Name = "chartControl2";
            this.chartControl2.PaletteBaseColorNumber = 3;
            series1.Name = "Aylar";
            series1.SeriesID = 1;
            sideBySideBarSeriesView1.Border.Color = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            series1.View = sideBySideBarSeriesView1;
            this.chartControl2.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series1};
            this.chartControl2.Size = new System.Drawing.Size(405, 326);
            this.chartControl2.TabIndex = 8;
            // 
            // groupControl12
            // 
            this.groupControl12.Controls.Add(this.chartControl1);
            this.groupControl12.Location = new System.Drawing.Point(0, 4);
            this.groupControl12.Name = "groupControl12";
            this.groupControl12.Size = new System.Drawing.Size(405, 353);
            this.groupControl12.TabIndex = 10;
            this.groupControl12.Text = "groupControl12";
            // 
            // chartControl1
            // 
            xyDiagram2.AxisX.VisibleInPanesSerializable = "-1";
            xyDiagram2.AxisY.VisibleInPanesSerializable = "-1";
            this.chartControl1.Diagram = xyDiagram2;
            this.chartControl1.Legend.LegendID = -1;
            this.chartControl1.Location = new System.Drawing.Point(0, 27);
            this.chartControl1.Name = "chartControl1";
            series2.Name = "Aylar";
            series2.SeriesID = 1;
            this.chartControl1.SeriesSerializable = new DevExpress.XtraCharts.Series[] {
        series2};
            this.chartControl1.Size = new System.Drawing.Size(406, 326);
            this.chartControl1.TabIndex = 7;
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.gridControl3);
            this.xtraTabPage1.Controls.Add(this.gridControl1);
            this.xtraTabPage1.Controls.Add(this.groupControl9);
            this.xtraTabPage1.Controls.Add(this.groupControl8);
            this.xtraTabPage1.Controls.Add(this.groupControl6);
            this.xtraTabPage1.Controls.Add(this.groupControl7);
            this.xtraTabPage1.Controls.Add(this.groupControl5);
            this.xtraTabPage1.Controls.Add(this.groupControl4);
            this.xtraTabPage1.Controls.Add(this.groupControl3);
            this.xtraTabPage1.Controls.Add(this.groupControl2);
            this.xtraTabPage1.Controls.Add(this.groupControl1);
            this.xtraTabPage1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("xtraTabPage1.ImageOptions.Image")));
            this.xtraTabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(1538, 723);
            this.xtraTabPage1.Text = "Kasa Giriş Hareketleri";
            // 
            // gridControl3
            // 
            this.gridControl3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl3.Location = new System.Drawing.Point(413, 357);
            this.gridControl3.MainView = this.gridView3;
            this.gridControl3.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl3.Name = "gridControl3";
            this.gridControl3.Size = new System.Drawing.Size(1625, 345);
            this.gridControl3.TabIndex = 20;
            this.gridControl3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView3});
            // 
            // gridView3
            // 
            this.gridView3.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gridView3.Appearance.Row.Options.UseBackColor = true;
            this.gridView3.DetailHeight = 431;
            this.gridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView3.GridControl = this.gridControl3;
            this.gridView3.Name = "gridView3";
            this.gridView3.OptionsEditForm.PopupEditFormWidth = 1067;
            // 
            // gridControl1
            // 
            this.gridControl1.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl1.Location = new System.Drawing.Point(413, 4);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Margin = new System.Windows.Forms.Padding(4);
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(1625, 345);
            this.gridControl1.TabIndex = 19;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gridView1.Appearance.Row.Options.UseBackColor = true;
            this.gridView1.DetailHeight = 431;
            this.gridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsEditForm.PopupEditFormWidth = 1067;
            // 
            // groupControl9
            // 
            this.groupControl9.Controls.Add(this.LblAktifKullanıcı);
            this.groupControl9.Controls.Add(this.label16);
            this.groupControl9.Location = new System.Drawing.Point(0, 499);
            this.groupControl9.Name = "groupControl9";
            this.groupControl9.ShowCaption = false;
            this.groupControl9.Size = new System.Drawing.Size(406, 56);
            this.groupControl9.TabIndex = 15;
            this.groupControl9.Text = "Kasa";
            // 
            // LblAktifKullanıcı
            // 
            this.LblAktifKullanıcı.AutoSize = true;
            this.LblAktifKullanıcı.Location = new System.Drawing.Point(180, 19);
            this.LblAktifKullanıcı.Name = "LblAktifKullanıcı";
            this.LblAktifKullanıcı.Size = new System.Drawing.Size(28, 17);
            this.LblAktifKullanıcı.TabIndex = 1;
            this.LblAktifKullanıcı.Text = "----";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(58, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 17);
            this.label16.TabIndex = 0;
            this.label16.Text = "Aktif Kullanıcı:";
            // 
            // groupControl8
            // 
            this.groupControl8.Controls.Add(this.LblStokSayısı);
            this.groupControl8.Controls.Add(this.label14);
            this.groupControl8.Location = new System.Drawing.Point(0, 437);
            this.groupControl8.Name = "groupControl8";
            this.groupControl8.ShowCaption = false;
            this.groupControl8.Size = new System.Drawing.Size(406, 56);
            this.groupControl8.TabIndex = 14;
            this.groupControl8.Text = "Kasa";
            // 
            // LblStokSayısı
            // 
            this.LblStokSayısı.AutoSize = true;
            this.LblStokSayısı.Location = new System.Drawing.Point(180, 19);
            this.LblStokSayısı.Name = "LblStokSayısı";
            this.LblStokSayısı.Size = new System.Drawing.Size(16, 17);
            this.LblStokSayısı.TabIndex = 1;
            this.LblStokSayısı.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(69, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 17);
            this.label14.TabIndex = 0;
            this.label14.Text = "Stok Sayısı:";
            // 
            // groupControl6
            // 
            this.groupControl6.Controls.Add(this.LblMüsteriSehirSayısı);
            this.groupControl6.Controls.Add(this.label3);
            this.groupControl6.Controls.Add(this.LblFirmaSehirSayısı);
            this.groupControl6.Controls.Add(this.label10);
            this.groupControl6.Location = new System.Drawing.Point(0, 313);
            this.groupControl6.Name = "groupControl6";
            this.groupControl6.ShowCaption = false;
            this.groupControl6.Size = new System.Drawing.Size(406, 56);
            this.groupControl6.TabIndex = 13;
            this.groupControl6.Text = "Kasa";
            // 
            // LblMüsteriSehirSayısı
            // 
            this.LblMüsteriSehirSayısı.AutoSize = true;
            this.LblMüsteriSehirSayısı.Location = new System.Drawing.Point(363, 19);
            this.LblMüsteriSehirSayısı.Name = "LblMüsteriSehirSayısı";
            this.LblMüsteriSehirSayısı.Size = new System.Drawing.Size(16, 17);
            this.LblMüsteriSehirSayısı.TabIndex = 3;
            this.LblMüsteriSehirSayısı.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(213, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Müşteri Şehir Sayısı:";
            // 
            // LblFirmaSehirSayısı
            // 
            this.LblFirmaSehirSayısı.AutoSize = true;
            this.LblFirmaSehirSayısı.Location = new System.Drawing.Point(180, 19);
            this.LblFirmaSehirSayısı.Name = "LblFirmaSehirSayısı";
            this.LblFirmaSehirSayısı.Size = new System.Drawing.Size(16, 17);
            this.LblFirmaSehirSayısı.TabIndex = 1;
            this.LblFirmaSehirSayısı.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 17);
            this.label10.TabIndex = 0;
            this.label10.Text = "Firma Şehir Sayısı:";
            // 
            // groupControl7
            // 
            this.groupControl7.Controls.Add(this.LblPersonelSayısı);
            this.groupControl7.Controls.Add(this.label12);
            this.groupControl7.Location = new System.Drawing.Point(0, 375);
            this.groupControl7.Name = "groupControl7";
            this.groupControl7.ShowCaption = false;
            this.groupControl7.Size = new System.Drawing.Size(406, 56);
            this.groupControl7.TabIndex = 12;
            this.groupControl7.Text = "Kasa";
            // 
            // LblPersonelSayısı
            // 
            this.LblPersonelSayısı.AutoSize = true;
            this.LblPersonelSayısı.Location = new System.Drawing.Point(180, 19);
            this.LblPersonelSayısı.Name = "LblPersonelSayısı";
            this.LblPersonelSayısı.Size = new System.Drawing.Size(16, 17);
            this.LblPersonelSayısı.TabIndex = 1;
            this.LblPersonelSayısı.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(46, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 17);
            this.label12.TabIndex = 0;
            this.label12.Text = "Personel Sayısı:";
            // 
            // groupControl5
            // 
            this.groupControl5.Controls.Add(this.LblFirmaSayısı);
            this.groupControl5.Controls.Add(this.label8);
            this.groupControl5.Location = new System.Drawing.Point(0, 251);
            this.groupControl5.Name = "groupControl5";
            this.groupControl5.ShowCaption = false;
            this.groupControl5.Size = new System.Drawing.Size(406, 56);
            this.groupControl5.TabIndex = 10;
            this.groupControl5.Text = "Kasa";
            // 
            // LblFirmaSayısı
            // 
            this.LblFirmaSayısı.AutoSize = true;
            this.LblFirmaSayısı.Location = new System.Drawing.Point(180, 19);
            this.LblFirmaSayısı.Name = "LblFirmaSayısı";
            this.LblFirmaSayısı.Size = new System.Drawing.Size(16, 17);
            this.LblFirmaSayısı.TabIndex = 1;
            this.LblFirmaSayısı.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(64, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 17);
            this.label8.TabIndex = 0;
            this.label8.Text = "Firma Sayısı:";
            // 
            // groupControl4
            // 
            this.groupControl4.Controls.Add(this.LblMüsteriSayısı);
            this.groupControl4.Controls.Add(this.label6);
            this.groupControl4.Location = new System.Drawing.Point(0, 189);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.ShowCaption = false;
            this.groupControl4.Size = new System.Drawing.Size(406, 56);
            this.groupControl4.TabIndex = 9;
            this.groupControl4.Text = "Kasa";
            // 
            // LblMüsteriSayısı
            // 
            this.LblMüsteriSayısı.AutoSize = true;
            this.LblMüsteriSayısı.Location = new System.Drawing.Point(180, 19);
            this.LblMüsteriSayısı.Name = "LblMüsteriSayısı";
            this.LblMüsteriSayısı.Size = new System.Drawing.Size(16, 17);
            this.LblMüsteriSayısı.TabIndex = 1;
            this.LblMüsteriSayısı.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(54, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "Müşteri Sayısı:";
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.LblPersonelMaasları);
            this.groupControl3.Controls.Add(this.label4);
            this.groupControl3.Location = new System.Drawing.Point(0, 127);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.ShowCaption = false;
            this.groupControl3.Size = new System.Drawing.Size(406, 56);
            this.groupControl3.TabIndex = 8;
            this.groupControl3.Text = "Kasa";
            // 
            // LblPersonelMaasları
            // 
            this.LblPersonelMaasları.AutoSize = true;
            this.LblPersonelMaasları.Location = new System.Drawing.Point(180, 20);
            this.LblPersonelMaasları.Name = "LblPersonelMaasları";
            this.LblPersonelMaasları.Size = new System.Drawing.Size(43, 17);
            this.LblPersonelMaasları.TabIndex = 1;
            this.LblPersonelMaasları.Text = "00 TL";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "Personel Maaşları:";
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.LblÖdemeler);
            this.groupControl2.Controls.Add(this.label2);
            this.groupControl2.Location = new System.Drawing.Point(0, 66);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.ShowCaption = false;
            this.groupControl2.Size = new System.Drawing.Size(406, 56);
            this.groupControl2.TabIndex = 7;
            this.groupControl2.Text = "Kasa";
            // 
            // LblÖdemeler
            // 
            this.LblÖdemeler.AutoSize = true;
            this.LblÖdemeler.Location = new System.Drawing.Point(180, 20);
            this.LblÖdemeler.Name = "LblÖdemeler";
            this.LblÖdemeler.Size = new System.Drawing.Size(43, 17);
            this.LblÖdemeler.TabIndex = 1;
            this.LblÖdemeler.Text = "00 TL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 17);
            this.label2.TabIndex = 0;
            this.label2.Text = "Yapılan Ödemeler:";
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.LblKasaToplam);
            this.groupControl1.Controls.Add(this.LblToplamTutar);
            this.groupControl1.Location = new System.Drawing.Point(0, 4);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.ShowCaption = false;
            this.groupControl1.Size = new System.Drawing.Size(406, 56);
            this.groupControl1.TabIndex = 6;
            this.groupControl1.Text = "Kasa";
            // 
            // LblKasaToplam
            // 
            this.LblKasaToplam.AutoSize = true;
            this.LblKasaToplam.Location = new System.Drawing.Point(180, 21);
            this.LblKasaToplam.Name = "LblKasaToplam";
            this.LblKasaToplam.Size = new System.Drawing.Size(43, 17);
            this.LblKasaToplam.TabIndex = 1;
            this.LblKasaToplam.Text = "00 TL";
            // 
            // LblToplamTutar
            // 
            this.LblToplamTutar.AutoSize = true;
            this.LblToplamTutar.Location = new System.Drawing.Point(52, 20);
            this.LblToplamTutar.Name = "LblToplamTutar";
            this.LblToplamTutar.Size = new System.Drawing.Size(95, 17);
            this.LblToplamTutar.TabIndex = 0;
            this.LblToplamTutar.Text = "Toplam Tutar:";
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage2;
            this.xtraTabControl1.Size = new System.Drawing.Size(1540, 753);
            this.xtraTabControl1.TabIndex = 1;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 400;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // FrmKasa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1540, 753);
            this.Controls.Add(this.xtraTabControl1);
            this.Name = "FrmKasa";
            this.Text = "KASA";
            this.Load += new System.EventHandler(this.FrmKasa_Load);
            this.xtraTabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl13)).EndInit();
            this.groupControl13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(sideBySideBarSeriesView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl12)).EndInit();
            this.groupControl12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).EndInit();
            this.xtraTabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl9)).EndInit();
            this.groupControl9.ResumeLayout(false);
            this.groupControl9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl8)).EndInit();
            this.groupControl8.ResumeLayout(false);
            this.groupControl8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl6)).EndInit();
            this.groupControl6.ResumeLayout(false);
            this.groupControl6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl7)).EndInit();
            this.groupControl7.ResumeLayout(false);
            this.groupControl7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl5)).EndInit();
            this.groupControl5.ResumeLayout(false);
            this.groupControl5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            this.groupControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            this.groupControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private System.Windows.Forms.Label LblMüsteriSayısı;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private System.Windows.Forms.Label LblPersonelMaasları;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.Label LblÖdemeler;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.Label LblKasaToplam;
        private System.Windows.Forms.Label LblToplamTutar;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraEditors.GroupControl groupControl9;
        private System.Windows.Forms.Label LblAktifKullanıcı;
        private System.Windows.Forms.Label label16;
        private DevExpress.XtraEditors.GroupControl groupControl8;
        private System.Windows.Forms.Label LblStokSayısı;
        private System.Windows.Forms.Label label14;
        private DevExpress.XtraEditors.GroupControl groupControl6;
        private System.Windows.Forms.Label LblFirmaSehirSayısı;
        private System.Windows.Forms.Label label10;
        private DevExpress.XtraEditors.GroupControl groupControl7;
        private System.Windows.Forms.Label LblPersonelSayısı;
        private System.Windows.Forms.Label label12;
        private DevExpress.XtraEditors.GroupControl groupControl5;
        private System.Windows.Forms.Label LblFirmaSayısı;
        private System.Windows.Forms.Label label8;
        private DevExpress.XtraCharts.ChartControl chartControl2;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private System.Windows.Forms.Label LblMüsteriSehirSayısı;
        private System.Windows.Forms.Label label3;
        private DevExpress.XtraEditors.GroupControl groupControl13;
        private DevExpress.XtraEditors.GroupControl groupControl12;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private DevExpress.XtraGrid.GridControl gridControl2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.GridControl gridControl3;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}